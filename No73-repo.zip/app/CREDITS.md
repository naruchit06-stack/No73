# Asset credits

## Demo cover images

Demo cover photographs are loaded from Unsplash under the Unsplash License:
https://unsplash.com/license

Source image IDs used in `db/seed.ts`:
- photo-1518709268805-4e9042af9f23
- photo-1500530855697-b586d89ba3ee
- photo-1516339901601-2e1b62dc0c45
- photo-1470252649378-9c29740c9fa8
- photo-1446776811953-b23d57bd21aa
- photo-1507525428034-b723cf961d3e

## Demo audio

The short demo audio samples are provided by Samplelib:
https://samplelib.com/

They are placeholder media for product demonstration and can be replaced by administrators through the upload workflow.

## Fonts and icons

- IBM Plex Sans Thai and Noto Serif Thai, served by Google Fonts under the SIL Open Font License.
- Lucide icons, under the ISC License.
