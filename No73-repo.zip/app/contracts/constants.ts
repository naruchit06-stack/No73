export const Session = {
  cookieName: "no73_sid",
  maxAgeMs: 365 * 24 * 60 * 60 * 1000,
} as const;

export const ErrorMessages = {
  unauthenticated: "Authentication required",
  insufficientRole: "Insufficient permissions",
} as const;

export const Paths = {
  login: "/login",
  googleStart: "/api/auth/google",
  oauthCallback: "/api/oauth/callback",
} as const;
