CREATE TABLE `episodes` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`novelId` bigint unsigned NOT NULL,
	`number` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`duration` int NOT NULL DEFAULT 0,
	`audioKey` text,
	`audioUrl` text,
	`isPremium` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `episodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `episode_novel_number_idx` UNIQUE(`novelId`,`number`)
);
--> statement-breakpoint
CREATE TABLE `listening_progress` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`episodeId` bigint unsigned NOT NULL,
	`position` int NOT NULL DEFAULT 0,
	`duration` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `listening_progress_id` PRIMARY KEY(`id`),
	CONSTRAINT `progress_user_episode_idx` UNIQUE(`userId`,`episodeId`)
);
--> statement-breakpoint
CREATE TABLE `novels` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`title` varchar(255) NOT NULL,
	`author` varchar(255) NOT NULL,
	`category` varchar(80) NOT NULL,
	`description` text NOT NULL,
	`coverKey` text,
	`coverUrl` text,
	`featured` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `novels_id` PRIMARY KEY(`id`),
	CONSTRAINT `novels_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `payment_requests` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`amount` int NOT NULL,
	`note` varchar(500),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewedBy` bigint unsigned,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payment_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` varchar(64) NOT NULL,
	`value` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `settings_key` PRIMARY KEY(`key`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`unionId` varchar(255) NOT NULL,
	`name` varchar(255),
	`email` varchar(320),
	`avatar` text,
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`memberUntil` timestamp,
	`notifiedSignup` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	`lastSignInAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_unionId_unique` UNIQUE(`unionId`)
);
--> statement-breakpoint
ALTER TABLE `episodes` ADD CONSTRAINT `episodes_novelId_novels_id_fk` FOREIGN KEY (`novelId`) REFERENCES `novels`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `listening_progress` ADD CONSTRAINT `listening_progress_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `listening_progress` ADD CONSTRAINT `listening_progress_episodeId_episodes_id_fk` FOREIGN KEY (`episodeId`) REFERENCES `episodes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payment_requests` ADD CONSTRAINT `payment_requests_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payment_requests` ADD CONSTRAINT `payment_requests_reviewedBy_users_id_fk` FOREIGN KEY (`reviewedBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `episode_novel_idx` ON `episodes` (`novelId`);--> statement-breakpoint
CREATE INDEX `progress_user_updated_idx` ON `listening_progress` (`userId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `novel_category_idx` ON `novels` (`category`);--> statement-breakpoint
CREATE INDEX `payment_status_created_idx` ON `payment_requests` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `payment_user_idx` ON `payment_requests` (`userId`);