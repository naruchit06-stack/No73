import { useMemo } from "react";
import { Link, useParams } from "react-router";
import { ArrowLeft, ArrowRight, Check, Clock3, ListMusic, Pause, Play } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { usePlayer } from "@/providers/PlayerProvider";
import { useAuth } from "@/hooks/useAuth";
import { CoverArt } from "@/components/CoverArt";
import { formatTime } from "@/types/player";
import type { PlayerTrack } from "@/types/player";

export default function StoryDetail() {
  const { slug = "" } = useParams();
  const { data, isLoading, error, refetch } = trpc.novel.detail.useQuery({ slug }, { enabled: Boolean(slug) });
  const { playTrack, toggle, current, isPlaying } = usePlayer();
  const { isAuthenticated } = useAuth();

  const tracks = useMemo<PlayerTrack[]>(() => (data?.episodes ?? []).flatMap((episode) => episode.audioUrl ? [{
    episodeId: episode.id,
    novelSlug: data!.novel.slug,
    novelTitle: data!.novel.title,
    episodeNumber: episode.number,
    episodeTitle: episode.title,
    audioUrl: episode.audioUrl,
    coverUrl: data!.novel.coverUrl,
    duration: episode.duration,
    position: episode.progress?.position ?? 0,
  }] : []), [data]);

  if (isLoading) return <main className="page-shell min-h-[80dvh] py-16"><div className="h-[480px] animate-pulse bg-[var(--surface)]" /></main>;
  if (error || !data) return (
    <main className="page-shell flex min-h-[75dvh] flex-col items-center justify-center text-center">
      <h1 className="font-display text-4xl">ไม่พบเรื่องนี้ในคลัง</h1>
      <p className="mt-3 text-[var(--muted)]">เรื่องนี้อาจถูกย้ายหรือนำออกแล้ว</p>
      <div className="mt-6 flex gap-3"><button type="button" className="button-secondary" onClick={() => void refetch()}>ลองใหม่</button><Link to="/library" className="button-primary">กลับคลังนิยาย</Link></div>
    </main>
  );

  const { novel, episodes } = data;
  const resumeTrack = tracks.find((track) => (track.position ?? 0) > 1 && (track.position ?? 0) < track.duration - 2) ?? tracks[0];
  const totalDuration = episodes.reduce((sum, episode) => sum + episode.duration, 0);

  return (
    <main>
      <section className="story-hero">
        <div className="hero-backdrop" style={novel.coverUrl ? { backgroundImage: `url("${novel.coverUrl}")` } : undefined} aria-hidden="true" />
        <div className="page-shell relative py-8 md:py-14">
          <Link to="/library" className="inline-flex min-h-11 items-center gap-2 text-sm text-[var(--text-soft)] hover:text-[var(--accent)]"><ArrowLeft size={17} /> คลังนิยาย</Link>
          <div className="mt-7 grid gap-8 md:grid-cols-[220px_1fr] md:gap-10 lg:grid-cols-[270px_1fr]">
            <CoverArt src={novel.coverUrl} title={novel.title} eager className="mx-auto aspect-[3/4] w-[210px] shadow-2xl md:mx-0 md:w-full" />
            <div className="flex flex-col justify-end">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-[var(--accent)]">{novel.category}</p>
              <h1 className="mt-3 font-display text-4xl font-semibold leading-tight md:text-6xl">{novel.title}</h1>
              <p className="mt-3 text-[var(--text-soft)]">เขียนโดย {novel.author}</p>
              <p className="mt-5 max-w-2xl text-base leading-8 text-[var(--text-soft)]">{novel.description}</p>
              <div className="mt-5 flex flex-wrap items-center gap-4 text-sm text-[var(--muted)]">
                <span className="inline-flex items-center gap-1.5"><ListMusic size={16} /> {episodes.length} ตอน</span>
                <span className="inline-flex items-center gap-1.5"><Clock3 size={16} /> รวม {formatTime(totalDuration)}</span>
              </div>
              {resumeTrack && (
                <button type="button" className="button-primary mt-7 self-start" onClick={() => playTrack(resumeTrack, tracks)}>
                  <Play size={18} fill="currentColor" /> {(resumeTrack.position ?? 0) > 1 ? "ฟังต่อจากที่ค้าง" : "เริ่มฟังตอนแรก"} <ArrowRight size={17} />
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="page-shell py-12 md:py-20">
        <div className="section-heading">
          <div><p className="section-kicker">สารบัญเสียง</p><h2 className="section-title">ทุกตอน</h2></div>
          <span className="text-sm text-[var(--muted)]">เล่นต่อเนื่องอัตโนมัติ</span>
        </div>

        {!isAuthenticated && (
          <div className="mb-6 flex flex-col gap-3 border border-[var(--line)] bg-[var(--surface)] p-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm leading-6 text-[var(--muted)]">เข้าสู่ระบบเพื่อบันทึกตำแหน่งและฟังต่อบนอุปกรณ์อื่น</p>
            <Link to="/login" className="inline-flex min-h-11 shrink-0 items-center text-sm font-medium text-[var(--accent)]">เข้าสู่ระบบ <ArrowRight size={16} /></Link>
          </div>
        )}

        <div className="episode-list">
          {episodes.map((episode) => {
            const track = tracks.find((item) => item.episodeId === episode.id);
            const active = current?.episodeId === episode.id;
            const progress = episode.progress && episode.progress.duration ? Math.min(100, episode.progress.position / episode.progress.duration * 100) : 0;
            const finished = progress > 96;
            return (
              <button
                type="button" key={episode.id} disabled={!track}
                onClick={() => {
                  if (!track) return;
                  if (active) toggle();
                  else playTrack(track, tracks);
                }}
                className={`episode-row ${active ? "active" : ""}`}
              >
                <span className="episode-number">{episode.number.toString().padStart(2, "0")}</span>
                <span className="min-w-0 flex-1 text-left">
                  <span className="block font-display text-lg font-medium md:text-xl">{episode.title}</span>
                  <span className="mt-1 flex items-center gap-2 text-xs text-[var(--muted)]">
                    {finished ? <><Check size={14} className="text-[var(--accent)]" /> ฟังจบแล้ว</> : episode.progress && episode.progress.position > 0 ? `ฟังแล้ว ${Math.round(progress)}%` : "ยังไม่ได้ฟัง"}
                  </span>
                  {progress > 0 && <span className="mt-3 block h-0.5 w-full max-w-md bg-[var(--line)]"><span className="block h-full bg-[var(--accent)]" style={{ width: `${progress}%` }} /></span>}
                </span>
                <span className="hidden text-xs tabular-nums text-[var(--muted)] sm:block">{formatTime(episode.duration)}</span>
                <span className={`episode-play ${active ? "active" : ""}`}>
                  {active && isPlaying ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}
                </span>
              </button>
            );
          })}
        </div>
      </section>
    </main>
  );
}
